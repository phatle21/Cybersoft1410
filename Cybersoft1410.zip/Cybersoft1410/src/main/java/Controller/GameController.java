package Controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = {"/controller"})
public class GameController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter printWriter = resp.getWriter();

        String randomNumber = req.getParameter("randomNumber");
        int secretNumber = Integer.parseInt(randomNumber);
        String number = req.getParameter("number");
        int userNumber = Integer.parseInt(number);

        if(userNumber > secretNumber){
            printWriter.print("<h1 style='color:yellow; text-align: center'>Số thử đoán lớn hơn số phải đoán</h1>");
            req.getRequestDispatcher("/service").include(req, resp);
        }else if(userNumber < secretNumber){
            printWriter.print("<h1 style='color:yellow; text-align: center'>Số thử đoán nhỏ hơn số phải đoán</h1>");
            req.getRequestDispatcher("/service").include(req, resp);
        }else{
            req.getRequestDispatcher("/user").forward(req, resp);
        }
    }
}
