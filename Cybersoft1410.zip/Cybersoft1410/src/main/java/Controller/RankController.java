package Controller;

import Model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;

@WebServlet(urlPatterns = {"/rank"})
public class RankController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter printWriter = resp.getWriter();

        ArrayList<User> listUser = new ArrayList<User>();

        // của class User
        // User ( public static ArrayList<String> arrayList = new ArrayList<String>(); )
        for(String user : User.arrayList){
            //         arrayList.add(userName + "---" + count);
            String[] object = user.split("---"); // tách dấu --- để lấy Name và Count
            User users = new User();
            users.setName(object[0]);
            users.setCount(Integer.parseInt(object[1]));
            listUser.add(users); // thêm vào object[0] và object[1]
        }
        // thuật toán sort
        for(int i = 0 ; i < listUser.size() ; i++){
            for(int j = i + 1 ; j < listUser.size(); j++){
                if(listUser.get(i).getCount() > listUser.get(i).getCount()){
                    Collections.swap(listUser,i,j);
                }
            }
        }
        // hiển thị qua table
        printWriter.print("<table style='text-align: center'>");
        printWriter.print("<tr><th>Tên</th><th>Số lần đoán</th></tr>");
        for(User user : listUser){
            printWriter.print("<tr>");
            printWriter.print("<td>"+user.getName()+"</td>");
            printWriter.print("<td>"+user.getCount()+"</td>");
            printWriter.print("</tr>");
        }
        printWriter.print("</table>");
        // quay về trang chủ
        printWriter.print("<form action='/Cybersoft1410/home' method='get'>");
        printWriter.print("<input type='submit' value='Trang chủ'>");
        printWriter.print("</form>");
    }
}
