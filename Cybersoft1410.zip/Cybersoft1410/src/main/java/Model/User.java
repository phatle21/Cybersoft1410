package Model;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(urlPatterns = {"/user"})
public class User extends HttpServlet {
    private String name;
    private int count;

    public User() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public static ArrayList<String> arrayList = new ArrayList<String>();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter printWriter = resp.getWriter();
        String userName = req.getParameter("username");
        String count = req.getParameter("count");
        // thêm vào mảng arrayList
        arrayList.add(userName + "---" + count);
        // dấu --- dùng để tách Name và Count trong RankController

        printWriter.print("<h1 style='color:red; text-align:center'>Chúc mừng bạn đã đoán đúng</h1>");
        printWriter.print("<form action='/Cybersoft1410/home' method='get' style='text-align:center'>");
        printWriter.print("<input type='submit' value='Trang chủ'>");
        printWriter.print("</form>");
        printWriter.print("<form action='/Cybersoft1410/rank' method='get' style='text-align:center'>");
        printWriter.print("<input type='submit' value='Xếp loại'>");
        printWriter.print("</form>");
        printWriter.print("</div>");
    }
}
