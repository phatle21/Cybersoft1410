package View;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = {"/home"})
public class HomeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        req.setCharacterEncoding("UTF-8");
        // dùng PrintWriter ghi file
        PrintWriter printWriter = resp.getWriter();
        // int b = (int)(Math.random()*(max-min+1)+min);
       int randomNumber = (int) (Math.random() * 1000 + 1);
       int count = 0;
        printWriter.print("<form action='/Cybersoft1410/service' method='post' style='text-align:center'>");
        printWriter.print("<h1>Chào mừng đến với trò chơi đoán số</h1>");
        printWriter.print("<input type='text' placeholder='Nhập tên của bạn...' name='username'>");
        printWriter.print("<input type='submit' value='Begin'>");
        printWriter.print("<div>");
        printWriter.print("<input type='text' name='randomNumber' value='"+randomNumber+"' style='display:none'>");
        printWriter.print("<input type='text' name='count' value='"+count+"' style='display:none'>");
        printWriter.print("</div>");
        printWriter.print("</form>");
    }
}
