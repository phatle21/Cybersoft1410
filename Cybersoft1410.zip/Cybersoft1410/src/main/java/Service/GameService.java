package Service;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(urlPatterns = {"/service"})
public class GameService extends HttpServlet {
    int randomNumber = (int) (Math.random()* 1000 + 1);
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        req.setCharacterEncoding("UTF-8");
        PrintWriter printWriter = resp.getWriter();
        String randomNumber = req.getParameter("randomNumber");
        int secretNumber = Integer.parseInt(randomNumber);
        String userName = req.getParameter("username");
        String count = req.getParameter("count");
        int countGuess = Integer.parseInt(count);
        countGuess++;
        printWriter.print("<form action='/Cybersoft1410/controller' method='post' style='text-align:center'>");
        printWriter.print("<h1 style='color: brown;'>Nhập số từ 1 đến 1000</h1>");
        printWriter.print("<input type='text' name='randomNumber' value='"+secretNumber+"' style='display:none'>");
        printWriter.print("Số lần đoán: <input type='text' style='text-align:center' name='count' value='"+countGuess+"'>");
        printWriter.print("Tên của bạn: <input type='text' style='text-align:center' name='username' value='"+userName+"'>");
        printWriter.print("Số bạn đoán: <input type='text' placeholder='Vui lòng chỉ nhập số' name='number' pattern='[0-9]+'>");
        printWriter.print("<input type='submit' value='Đoán thử'>");
        printWriter.print("</form>");
    }
}
